//package com.epul.permispiste.controller;
//
//import org.springframework.web.bind.annotation.*;
//
//
//@RequestMapping("/objectif")
//@RestController
//@CrossOrigin
//public class ControllerObjectif {
//
//}
//
