package com.epul.permispiste.service;

import org.springframework.stereotype.Service;

@Service
interface IInscriptionService {
}
